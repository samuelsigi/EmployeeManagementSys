const express = require('express');
const HttpError = require('../Model/http-error');
const {validationResult} = require ('express-validator');
const Employee = require('../Model/employee');
const Department = require('../Model/department');
const mongoose = require('mongoose');
const department = require('../Model/department');
const employee = require('../Model/employee');

const createEmployee = async (req,res,next)=>{
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        console.log(errors);
        throw new HttpError('Invalid Inputs passed, please check your data',422)
    }
    const {fullname, email, position, dateOfBirth, dateOfJoining, salary} = req.body;
    const createEmployee = new Employee ({
        fullname:fullname,
        email:email,
        position:position,
        dateOfBirth:dateOfBirth,
        dateOfJoining:dateOfJoining,
        salary:salary

    })
    let dept;
    try{
        dept = await User.findById(department)
    }catch(err){
        const error  = new HttpError('creating employee failed,try again',500)
        return next(error)
    }
    if(!dept){
        const error = new HttpError('could not find department with id,try again',404);
        return next(error);
    }
    try{
        const sess = await mongoose.startSession();
        sess.startTransaction();
        await createEmployee.save({session:sess});
        employee.department.push(createEmployee);
        await user.save({session:sess});
        await sess.commitTransaction();
    }catch(err){
        const error = new HttpError('adding place failed',500);
        return next(error)
    }


    res.status(201).json({employee:createEmployee});
}


const updateEmployee = async (req,res,next)=>{
    const {fullname, email, position, dateOfBirth, dateOfJoining, salary} = req.body;
    const employeeId = req.params.empid;
    let employee;
    try {
        employee = await Employee.findByIdAndUpdate({_id:employeeId},{$set:{fullname:fullname,
             email:email, position:position, dateOfBirth:dateOfBirth, 
             dateOfJoining:dateOfJoining, salary:salary}})
    }
    catch(err){
        const error = new HttpError('Something Went Wrong,Could Not Update Employee',500);
        return next(error);

    }
    if(!employee){
        throw new HttpError('Could Not Find A Employee With Given Id',404)
    }
    res.status(200).json({employee:employee});
}


const deleteEmployee = async (req,res,next)=>{
    const employeeId = req.params.empid;
    let employee;
    try {
        employee = await Employee.deleteOne({ _id:employeeId});
    }
    catch(err){
        const error = new HttpError('Something Went Wrong,Could Not Delete Employee',500);
        return next(error);

    }
    if(!employee){
        throw new HttpError('Could Not Find A Employee With Given Id',404)
    }
    res.status(200).json({message:'Employee Successfully Deleted :)'});
}


const getEmployeeById = async (req,res,next)=>{
    console.log('GET Request in employees');
    const employeeId = req.params.empid;
    let employee;
    try {
        employee = await Employee.findById(employeeId)
    }
    catch(err){
        const error = new HttpError('Something Went Wrong,Could Not Find Employee',500);
        return next(error);

    }
    if(!employee){
        throw new HttpError('Could Not Find A Employee With Given Id',404)
    }
    res.json({employee:employee.toObject({getters:true})})
}


const getAllEmployee = async (req,res,next)=>{
    console.log('GET Request in employees');
    let employee;
    try {
        employee = await Employee.find()
    }
    catch(err){
        const error = new HttpError('Something Went Wrong,Could Not Find A Employee',500);
        return next(error);

    }
    if(!employee){
        throw new HttpError('Could Not Find A Employee With Given Id',404)
    }
    res.json({employee:employee})
}

exports.createEmployee = createEmployee
exports.updateEmployee = updateEmployee
exports.deleteEmployee = deleteEmployee
exports.getEmployeeById = getEmployeeById
exports.getAllEmployee = getAllEmployee


